package com.terminalpermission;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.block.DispenserBlock;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraft.world.entity.player.Player;

import java.util.UUID;

@Mod(TerminalPermission.MODID)
public class TerminalPermission {
    public static final String MODID = "terminalpermission";
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MODID);

    public static final ArmorMaterial TERMINAL_MATERIAL = new ArmorMaterial() {
        @Override public int getDurabilityForType(ArmorItem.Type type) {
            return switch (type) {
                case HELMET -> 407;
                case CHESTPLATE -> 592;
                case LEGGINGS -> 555;
                case BOOTS -> 481;
            };
        }
        @Override public int getDefenseForType(ArmorItem.Type type) { return 30; }
        @Override public int getEnchantmentValue() { return 100; }
        @Override public net.minecraft.sounds.SoundEvent getEquipSound() {
            return SoundEvents.ARMOR_EQUIP_NETHERITE;
        }
        @Override public Ingredient getRepairIngredient() { return Ingredient.of(Items.NETHER_STAR); }
        @Override public String getName() { return MODID + ":terminal"; }
        @Override public float getToughness() { return 1000.0F; }
        @Override public float getKnockbackResistance() { return 1.0F; }
    };

    public static final RegistryObject<Item> TERMINAL_HELMET = ITEMS.register("terminal_helmet",
            () -> new ArmorItem(TERMINAL_MATERIAL, ArmorItem.Type.HELMET, new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> TERMINAL_CHESTPLATE = ITEMS.register("terminal_chestplate",
            () -> new ArmorItem(TERMINAL_MATERIAL, ArmorItem.Type.CHESTPLATE, new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> TERMINAL_LEGGINGS = ITEMS.register("terminal_leggings",
            () -> new ArmorItem(TERMINAL_MATERIAL, ArmorItem.Type.LEGGINGS, new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> TERMINAL_BOOTS = ITEMS.register("terminal_boots",
            () -> new ArmorItem(TERMINAL_MATERIAL, ArmorItem.Type.BOOTS, new Item.Properties().fireResistant()));

    public TerminalPermission() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(modBus);
        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(TerminalAI.class);
    }

    @SubscribeEvent
    public void onCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("terminalpermission")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("release")
                        .then(Commands.argument("player", EntityArgument.player())
                                .executes(ctx -> {
                                    Player player = EntityArgument.getPlayer(ctx, "player");
                                    TerminalAI.release(player);
                                    ctx.getSource().sendSuccess(
                                            () -> Component.literal("已解除 " + player.getGameProfile().getName() + " 的终末权限接管。"),
                                            true);
                                    return 1;
                                }))));
    }
}
