package com.terminalpermission.client;

import com.terminalpermission.TerminalPermission;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = TerminalPermission.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class TerminalClientEvents {
    private TerminalClientEvents() {}

    @SubscribeEvent
    public static void lockManualControls(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        boolean fullSet =
                mc.player.getInventory().armor.get(3).is(TerminalPermission.TERMINAL_HELMET.get())
                && mc.player.getInventory().armor.get(2).is(TerminalPermission.TERMINAL_CHESTPLATE.get())
                && mc.player.getInventory().armor.get(1).is(TerminalPermission.TERMINAL_LEGGINGS.get())
                && mc.player.getInventory().armor.get(0).is(TerminalPermission.TERMINAL_BOOTS.get());

        if (!fullSet) return;

        // Inventory remains available; movement and manual combat inputs are suppressed.
        mc.options.keyUp.setDown(false);
        mc.options.keyDown.setDown(false);
        mc.options.keyLeft.setDown(false);
        mc.options.keyRight.setDown(false);
        mc.options.keyJump.setDown(false);
        mc.options.keyShift.setDown(false);
        mc.options.keySprint.setDown(false);
        mc.options.keyAttack.setDown(false);
        mc.options.keyUse.setDown(false);
    }
}
