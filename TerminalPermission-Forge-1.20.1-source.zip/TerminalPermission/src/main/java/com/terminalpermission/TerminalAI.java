package com.terminalpermission;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Comparator;
import java.util.UUID;

@Mod.EventBusSubscriber(modid = TerminalPermission.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class TerminalAI {
    private static final String ACTIVE = "terminalpermission_active";
    private static final String PREVIOUS_INVULNERABLE = "terminalpermission_previous_invulnerable";
    private static final UUID SPEED_ID = UUID.fromString("5d4f7a20-efab-4f4d-a5f3-32f0cafe1001");
    private static final UUID DAMAGE_ID = UUID.fromString("5d4f7a20-efab-4f4d-a5f3-32f0cafe1002");

    private TerminalAI() {}

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.level().isClientSide) return;
        Player player = event.player;

        if (isFullSet(player)) {
            if (!player.getPersistentData().getBoolean(ACTIVE)) activate(player);
        }

        if (!player.getPersistentData().getBoolean(ACTIVE)) return;

        keepArmorEquipped(player);
        player.getAbilities().invulnerable = true;
        if (player instanceof ServerPlayer serverPlayer) serverPlayer.onUpdateAbilities();

        // Void protection: return the wearer to a safe height.
        if (player.getY() < player.level().getMinBuildHeight() + 2) {
            player.teleportTo(player.getX(), player.level().getMaxBuildHeight() - 16, player.getZ());
            player.setDeltaMovement(Vec3.ZERO);
            player.fallDistance = 0;
        }

        // Find the nearest living non-player target. This avoids attacking other players by default.
        LivingEntity target = player.level().getEntitiesOfClass(
                        LivingEntity.class, player.getBoundingBox().inflate(40),
                        entity -> entity != player && entity.isAlive() && !(entity instanceof Player))
                .stream()
                .min(Comparator.comparingDouble(player::distanceToSqr))
                .orElse(null);

        if (target == null) {
            player.setSprinting(true);
            return;
        }

        double dx = target.getX() - player.getX();
        double dy = target.getY() - player.getY();
        double dz = target.getZ() - player.getZ();
        double horizontal = Math.sqrt(dx * dx + dz * dz);

        float yaw = (float) (Mth.atan2(dz, dx) * (180.0D / Math.PI)) - 90.0F;
        float pitch = (float) (-(Mth.atan2(dy, Math.max(horizontal, 0.001D)) * (180.0D / Math.PI)));
        player.setYRot(yaw);
        player.setYHeadRot(yaw);
        player.setXRot(pitch);

        if (player.distanceToSqr(target) > 5.0D) {
            Vec3 direction = new Vec3(dx, dy, dz).normalize();
            player.setDeltaMovement(direction.scale(0.72D));
            player.hurtMarked = true;
            player.setSprinting(true);
        } else {
            player.setDeltaMovement(Vec3.ZERO);
            if (player.tickCount % 4 == 0) {
                player.attack(target);
                target.hurt(player.damageSources().playerAttack(player), 1.0E9F);
                if (target.isAlive()) target.kill();
            }
        }
    }

    private static boolean isFullSet(Player player) {
        return player.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.HEAD).is(TerminalPermission.TERMINAL_HELMET.get())
                && player.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.CHEST).is(TerminalPermission.TERMINAL_CHESTPLATE.get())
                && player.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.LEGS).is(TerminalPermission.TERMINAL_LEGGINGS.get())
                && player.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.FEET).is(TerminalPermission.TERMINAL_BOOTS.get());
    }

    private static void activate(Player player) {
        player.getPersistentData().putBoolean(ACTIVE, true);
        player.getPersistentData().putBoolean(PREVIOUS_INVULNERABLE, player.getAbilities().invulnerable);
        player.getAbilities().invulnerable = true;
        if (player instanceof ServerPlayer serverPlayer) serverPlayer.onUpdateAbilities();
        player.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                "§5[终末权限] §f完整终末系列已绑定。AI 接管已启动。管理员可使用 /terminalpermission release <玩家> 解除。"));
    }

    private static void keepArmorEquipped(Player player) {
        var inventory = player.getInventory();
        var slots = new net.minecraft.world.entity.EquipmentSlot[] {
                net.minecraft.world.entity.EquipmentSlot.HEAD,
                net.minecraft.world.entity.EquipmentSlot.CHEST,
                net.minecraft.world.entity.EquipmentSlot.LEGS,
                net.minecraft.world.entity.EquipmentSlot.FEET
        };
        var items = new net.minecraft.world.item.Item[] {
                TerminalPermission.TERMINAL_HELMET.get(),
                TerminalPermission.TERMINAL_CHESTPLATE.get(),
                TerminalPermission.TERMINAL_LEGGINGS.get(),
                TerminalPermission.TERMINAL_BOOTS.get()
        };

        for (int i = 0; i < slots.length; i++) {
            if (player.getItemBySlot(slots[i]).is(items[i])) continue;
            for (int slot = 0; slot < inventory.getContainerSize(); slot++) {
                var stack = inventory.getItem(slot);
                if (stack.is(items[i])) {
                    inventory.setItem(slot, player.getItemBySlot(slots[i]));
                    player.setItemSlot(slots[i], stack);
                    break;
                }
            }
        }
    }

    public static void release(Player player) {
        player.getPersistentData().putBoolean(ACTIVE, false);
        boolean previous = player.getPersistentData().getBoolean(PREVIOUS_INVULNERABLE);
        player.getAbilities().invulnerable = previous;
        if (player instanceof ServerPlayer serverPlayer) serverPlayer.onUpdateAbilities();
        player.setDeltaMovement(Vec3.ZERO);
        // Admin release also returns the bound set to the player's inventory,
        // so the client-side movement lock cannot immediately reactivate.
        var slots = new net.minecraft.world.entity.EquipmentSlot[] {
                net.minecraft.world.entity.EquipmentSlot.HEAD,
                net.minecraft.world.entity.EquipmentSlot.CHEST,
                net.minecraft.world.entity.EquipmentSlot.LEGS,
                net.minecraft.world.entity.EquipmentSlot.FEET
        };
        for (var slot : slots) {
            var stack = player.getItemBySlot(slot);
            if (stack.isEmpty()) continue;
            player.setItemSlot(slot, net.minecraft.world.item.ItemStack.EMPTY);
            if (!player.getInventory().add(stack)) player.drop(stack, false);
        }
        player.sendSystemMessage(net.minecraft.network.chat.Component.literal("§a[终末权限] AI 接管已解除，装备已归还。"));
    }
}
