# 终末权限（Terminal Permission）

- Minecraft Java：1.20.1
- Forge：47.2.0
- Java：17
- 模组版本：1.0.0

## 当前原型功能
- 终末头盔、胸甲、护腿、靴子四件套
- 全套穿戴后激活绑定与 AI 接管
- 服务端无敌、虚空跌落保护、强化移动
- AI 自动追击并击杀附近非玩家生物
- 客户端屏蔽移动、跳跃、攻击和使用按键；背包仍可打开
- 管理员解除命令：`/terminalpermission release <玩家>`

## 构建
需要 JDK 17 和网络连接以下载 Gradle / ForgeGradle 依赖。

在项目目录执行：
```bash
gradle build
```
成品通常位于 `build/libs/terminalpermission-1.0.0.jar`。

## 注意
这是第一版可扩展原型。当前护甲模型贴图是透明占位资源，物品图标也需要补绘；若你需要完整美术资源，下一步可以制作四件套图标、盔甲模型与特效。
